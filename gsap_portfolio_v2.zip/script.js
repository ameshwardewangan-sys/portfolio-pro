gsap.registerPlugin(ScrollTrigger);

gsap.from("h1",{y:50,opacity:0,duration:1});

gsap.utils.toArray(".project-card").forEach(card=>{
gsap.from(card,{
scrollTrigger:card,
y:80,
opacity:0,
duration:1
});
});

document.querySelectorAll(".project-card").forEach(card=>{
card.addEventListener("mouseenter",()=>{
gsap.to(card,{scale:1.05,duration:0.3});
});
card.addEventListener("mouseleave",()=>{
gsap.to(card,{scale:1,duration:0.3});
});
});
